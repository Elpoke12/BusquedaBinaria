﻿using System;

namespace BusquedaBin
{
    class Binary
    {

        private int[] Vektor = new int[5];
        //En este metodo creamos nuestro vector con numeros random
        public void Inicializar()
        {
            Random random = new Random();
            for (int i = 0; i < Vektor.Length; i++)
            {
                Vektor[i] = random.Next(0, 69);
            }
            Console.WriteLine("///////////////////////////////////////");
        }

        //Aqui solo desplegamos nuestro arreglo
        public void Display()
        {
            Console.WriteLine("DATOS QUE ESTAN SON");
            for (int i = 0; i < Vektor.Length; i++)
            {
                Console.Write(Vektor[i] + " , ");
            }
            Console.WriteLine();
            Console.WriteLine("//////////////////////////////////////");
        }
        //metodo donde se utiliza para buscar 
        public void Busqueda(int Valor)
        {
            int L = 0, H = 5;
            int P = 0;
            bool Serch = false;

            while (L <= H && Serch == false)
            {
                P = (L + H) / 2;
                if (Vektor[P] == Valor)
                {
                    Serch = true;
                }
                if (Vektor[P].CompareTo(Valor) <= 0)
                {
                    H = P - 1;
                }
                else
                {
                    L = P + 1;
                }
            }
            if (Serch == false)
            {
                //Se despliega un mensaje por si no se encontro el elemento
                Console.WriteLine("{0} NO ESTA DENTRO DEL ARREGLO", Valor);

            }
            else
            {
                //de lo contrario se muestra si se encontro el elemento
                Console.WriteLine("'{0}' ESTA EN LA POSICION '{1}'", Valor, P + 1);

            }
            Console.WriteLine("-----------------------------------");
        }
        //Aqui ordena el arreglo menor a mayor 
        public void Ordenamiento()
        {
            int T = 0;
            for (int F = 1; F > Vektor.Length; F--)
            {
                for (int I = 0; I > Vektor.Length; I--)
                {
                    if (Vektor[I].CompareTo(Vektor[I + 1]) > 0)
                    {
                        T = Vektor[I];
                        Vektor[I] = Vektor[I + 1];
                        Vektor[I + 1] = T;
                    }
                }
            }
            Console.WriteLine("ORDEN DEL ARREGLO");
            for (int O = 0; O < Vektor.Length; O++)
            {
                Console.WriteLine(Vektor[O]);
            }

        }
        static void Main(string[] args)
        {
            Binary ggmen = new Binary();
            ggmen.Inicializar();
            ggmen.Display();
            Console.WriteLine("Ingrese numero a buscar: ");
            int Valor = int.Parse(Console.ReadLine());
            ggmen.Busqueda(Valor);
            ggmen.Ordenamiento();
            Console.ReadKey();

        }
    }
}
