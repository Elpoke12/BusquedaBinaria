﻿using System;
using System.Collections.Generic;

namespace BusquedaBinaria
{
    class Binary
    {
        private string[] Colores;
        //Metodo donde creamos nuestro arreglo de colores
        public void Load()
        {
            Colores = new string[4];

            Console.WriteLine("Colres");
            for (int i = 0; i < Colores.Length; i++)
            {
                Console.Write("Ingrese elemento " + (i + 1) + ": ");
                Colores[i] = Console.ReadLine();
            }
            Console.WriteLine("///////////////////////////");
        }
        //desplegamos nuestros datos
        public void Display()
        {
            Console.WriteLine("Arreglo Desordenado");
            for (int x = 0; x < Colores.Length; x++)
            {
                Console.WriteLine(Colores[x]);
            }
            Console.WriteLine("///////////////////////////");
        }
        //Aqui utilizamos este metodo para buscar nuestros elementos
        public void Busqueda(string Valor)
        {
            int l = 0, h = 4;
            int m = 0;
            bool serch = false;

            while (l <= h && serch == false)
            {
                m = (l + h) / 2;
                if (Colores[m] == Valor)
                {
                    serch = true;
                }
                if (Colores[m].CompareTo(Valor) <= 0)
                {
                    h = m - 1;
                }
                else
                {
                    l = m + 1;
                }
            }
            if (serch == false)
            {
                //Se despliega un mensaje por si no se encontro el elemento
                Console.WriteLine("El elemento {0} no esta en el arreglo", Valor);

            }
            else
            {
                //de lo contrario se muestra si se encontro el elemento
                Console.WriteLine("El elemento '{0}' esta en la posicion '{1}'", Valor, m + 1);
            }
            Console.WriteLine("///////////////////////////");
        }
        //Aqui ordena el arreglo de manera alfabetica
        public void Imprimir()
        {
            string t = " ";
            for (int a = 1; a < Colores.Length; a++)
            {
                for (int b = 0; b < Colores.Length - a; b++)
                {
                    if (Colores[b].CompareTo(Colores[b + 1]) > 0)
                    {
                        t = Colores[b];
                        Colores[b] = Colores[b + 1];
                        Colores[b + 1] = t;
                    }
                }
            }//arreglo ordenado
            Console.WriteLine("Arreglo Ordenado");
            for (int x = 0; x < Colores.Length; x++)
            {
                Console.WriteLine(Colores[x]);
            }

        }
        static void Main(string[] args)
        {
            Binary ggmen = new Binary();
            ggmen.Load();
            ggmen.Display();
            Console.WriteLine("Ingrese el Color que desea buscar: ");
            string Valor = Console.ReadLine();
            ggmen.Busqueda(Valor);
            ggmen.Imprimir();

            Console.ReadKey();


        }
    }
}
